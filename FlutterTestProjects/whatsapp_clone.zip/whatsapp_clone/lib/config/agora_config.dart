class AgoraConfig {
  static String token = '';
  static String appId = '1d3d9e134485463082744ee67ecb2e3a';
  static String appCertificate = '6409927001f743dc91e3cf676244b253';
}
